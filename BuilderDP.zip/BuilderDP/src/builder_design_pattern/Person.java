package builder_design_pattern;

public class Person {
    private String name;
    private String country;
    private String officeAddress;
    private String homeAddress;
    private String companyName;
    private String age;
    private String noofsibiling;
    private String spousename;
    private String spouseage;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getNoofsibiling() {
		return noofsibiling;
	}
	public void setNoofsibiling(String noofsibiling) {
		this.noofsibiling = noofsibiling;
	}
	public String getSpousename() {
		return spousename;
	}
	public void setSpousename(String spousename) {
		this.spousename = spousename;
	}
	public String getSpouseage() {
		return spouseage;
	}
	public void setSpouseage(String spouseage) {
		this.spouseage = spouseage;
	}
    
  
    
}
