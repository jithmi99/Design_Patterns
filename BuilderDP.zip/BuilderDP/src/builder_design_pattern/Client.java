package builder_design_pattern;


public class Client {
	public static void main(String[] args) {
		Person john = new Person();
		john.setCountry(India);
		
		
	}

}
