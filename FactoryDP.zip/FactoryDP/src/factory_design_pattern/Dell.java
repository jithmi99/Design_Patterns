package factory_design_pattern;

public class Dell extends Laptop {

	private String ram;
	private String processor;
	public Dell(String ramSize, String processorType) {
		this.ram=ramSize;
		this.processor=processorType;
	}
	
	@Override
	public String getConfiguration() {
		
		return "Dell config is Ram Size " + this.ram + " and Processor Type is" + this.processor;
	}

	@Override
	public String toString() {
		return "Dell {"ram=" + ram + , processorType=" + processor + "}";
	}

}
