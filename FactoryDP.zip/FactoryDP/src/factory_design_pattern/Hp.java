package factory_design_pattern;

public class Hp extends Laptop {

	private String ram;
	private String processor;
	public Hp(String ramSize, String processorType) {
		this.ram=ramSize;
		this.processor=processorType;
	}
	
	@Override
	public String getConfiguration() {
		
		return "Hp config id Ram " + this.ram + " and Processor Type is" + this.processor;
	}

	@Override
	public String toString() {
		return "Hp [ram=" + ram + ", processorType=" + processor + "]";
	}

}
