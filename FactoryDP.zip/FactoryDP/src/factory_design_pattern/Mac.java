package factory_design_pattern;

public class Mac extends Laptop {

	private String ram;
	private String processor;
	private String gpu;
	public Mac(String ramSize, String processorType, String gpu) {
		this.ram=ramSize;
		this.processor=processorType;
		this.gpu=gpu;
	}
	
	@Override
	public String getConfiguration() {
		
		return "MacBook config id Ram " + this.ram + " and Processor Type is" + this.processor;
	}

	@Override
	public String toString() {
		return "Mac [ram=" + ram + ", processorType=" + processor + "]";
	}

}
