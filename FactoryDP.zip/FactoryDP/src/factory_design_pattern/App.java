package factory_design_pattern;

public class App {


	public static void main(String[] args) {
		
		Laptop dell = new Dell(ramSize, pr)
		Laptop mac = new Mac( ramSize "12gb",: "intel",gpu);
		Laptop hp = new Hp( ramSize: "16gb", processorType: "amd");
		System.out.println(dell.getConfiguration());
		System.out.println(dell.toString());
		System.out.println(mac.getConfiguration());
		System.out.println(mac.toString());
		System.out.println(hp.getConfiguration());
		System.out.println(hp.toString());
	}

}
