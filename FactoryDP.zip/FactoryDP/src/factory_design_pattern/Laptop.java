package factory_design_pattern;

public abstract class Laptop {
     public abstract String getConfiguration();
}
