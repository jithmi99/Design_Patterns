package singleton_design_pattern;

public class App {

	public static void main(String[] args) {
		System.out.println("This is singleton Design Pattern");
		
		EagerSingleton obj1 = EagerSingleton.getInstance();
		
		System.out.println(obj1.hashCode());
		
		EagerSingleton obj2 = EagerSingleton.getInstance();
		
		System.out.println(obj2.hashCode());

	}

}
